/**
 * @class Ext.ux.SysHeader
 * @extends Ext.util.Observable
 */
Ext.ux.SysHeader = function(app) {
	this.app = app;
	this.init();
}

Ext.extend(Ext.ux.SysHeader, Ext.util.Observable, {
			init : function() {
/*var sysMenu = new Ext.Toolbar({
        	renderTo: 'ux-sysmenus-panel',
        	items:[
        	{
        text: 'Toggle Me',
        enableToggle: true,
        //toggleHandler: onItemToggle,
        pressed: true
    }, '-',
    {text: 'Toggle Me2',
        enableToggle: true,
        //toggleHandler: onItemToggle,
        pressed: true
    }]
        });*/

				return this;
			}
		});