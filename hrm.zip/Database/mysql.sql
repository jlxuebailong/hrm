CREATE TABLE  hr_users (
	user_id int NOT NULL AUTO_INCREMENT,
	login_name varchar(100),
	password varchar(255),
PRIMARY key (user_id)
) COMMENT='';
