/*!
 * Ext JS Library 3.0.0
 * Copyright(c) 2006-2009 Ext JS, LLC
 * licensing@extjs.com
 * http://www.extjs.com/license
 */
Ext.lib.Dom.getRegion = function(el) {
    return Ext.lib.Region.getRegion(el);
};